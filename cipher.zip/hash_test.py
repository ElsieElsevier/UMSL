from Crypto.Hash import SHA256

hash_algo = SHA256.new()
file_data = open("logo.jpg", "rb")
data = file_data.read()
file_data.close()
hash_algo.update(data)
print (hash_algo.hexdigest())
