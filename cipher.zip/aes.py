from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes

key = get_random_bytes(16) # 128 bit AES key
print ('key:', [hex(x) for x in key])

iv = get_random_bytes(16) # 128 bit IV
aes = AES.new(key, AES.MODE_CBC, iv) # AES CBC mode
aes_E = AES.new(key, AES.MODE_ECB) # AES ECB mode

data = b"Hello Cipher 101" # <- 16 bytes
ciphertext = aes.encrypt(data)
ciphertext_E = aes_E.encrypt(data)
print("CBC ciphertext :", ciphertext)
print("ECB ciphertext :", ciphertext_E)

aes = AES.new(key, AES.MODE_CBC, iv)
plaintext = aes.decrypt(ciphertext)
plaintext_E = aes_E.decrypt(ciphertext_E)
assert plaintext == data
print ("Plaintext from CBC: ", plaintext)
print ("Plaintext from CBC: ", plaintext_E)
assert plaintext == plaintext_E
print ("Both plaintext Match")
